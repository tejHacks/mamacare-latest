import { useState } from "react";

export default function Footer() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: Replace this with API call to store/send contact message
    console.log("Contact Message:", formData);
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <footer className="bg-gray-900 text-white py-16 px-6">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12">
        {/* Left: About */}
        <div>
          <h2 className="text-3xl font-bold mb-4 text-pink-400">MamaHub 🍼</h2>
          <p className="text-gray-300 mb-6">
            From diapers to devotionals, MamaHub is your all-in-one baby and soul care companion.
            We’re building a home for mamas, by mamas — powered by code, compassion & Christ.
          </p>
          <p className="text-sm text-gray-500">&copy; {new Date().getFullYear()} MamaHub. All rights reserved.</p>
        </div>

        {/* Right: Contact Form */}
        <div>
          <h3 className="text-2xl font-semibold mb-4 text-white">Contact Us ✉️</h3>
          {submitted ? (
            <p className="text-green-400">Thank you for reaching out! We’ll get back to you soon. 🙏</p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full p-3 bg-gray-800 text-white rounded-lg border border-gray-600"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full p-3 bg-gray-800 text-white rounded-lg border border-gray-600"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
              <textarea
                rows="4"
                placeholder="Your Message"
                className="w-full p-3 bg-gray-800 text-white rounded-lg border border-gray-600"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
              />
              <button
                type="submit"
                className="bg-pink-600 hover:bg-pink-700 px-6 py-3 rounded-lg text-white font-semibold"
              >
                Send Message
              </button>
            </form>
          )}
        </div>
      </div>
    </footer>
  );
}
