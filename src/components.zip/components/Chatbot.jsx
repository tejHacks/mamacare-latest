import { useState } from "react";
import axios from "axios";

export default function Chatbot() {
  const [messages, setMessages] = useState([{ role: "system", content: "You're a helpful assistant for mothers." }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    const newMessages = [...messages, userMessage];

    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: newMessages,
        },
        {
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
        }
      );

      const reply = res.data.choices[0].message;
      setMessages([...newMessages, reply]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="bg-white/5 p-6 md:p-10 rounded-xl border border-white/10 backdrop-blur-md text-white max-w-4xl mx-auto my-12">
      <h2 className="text-3xl font-bold mb-6 text-center">MamaBot AI 🤖</h2>

      <div className="space-y-4 h-96 overflow-y-auto mb-4 p-2 bg-white/10 rounded-lg">
        {messages.slice(1).map((msg, i) => (
          <div key={i} className={`p-3 rounded-md ${msg.role === "user" ? "bg-pink-500/20" : "bg-purple-500/10"}`}>
            <strong>{msg.role === "user" ? "You" : "MamaBot"}:</strong> {msg.content}
          </div>
        ))}
        {loading && <p className="text-gray-300 animate-pulse">Typing...</p>}
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          className="flex-1 p-3 bg-gray-900 border border-gray-700 rounded-md text-white"
          placeholder="Ask MamaBot anything..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          onClick={sendMessage}
          className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-3 rounded-lg font-semibold"
        >
          Send
        </button>
      </div>
    </section>
  );
}
