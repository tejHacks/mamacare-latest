import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { FaArrowDown, FaHeart, FaStar, FaSmile } from "react-icons/fa";

import image1 from "/assets/woman.jpg";
import image2 from "/assets/woman.jpg";
import image3 from "/assets/woman.jpg";
import image4 from "/assets/woman.jpg";

const messages = [
  "A Modern Hub for Mothers",
  "Track Baby Milestones",
  "Connect with Loving Moms",
  "Raise Your Child With Confidence",
];

const images = [image1, image2, image3, image4];

export default function Hero() {
  const [index, setIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [key, setKey] = useState(0);

  useEffect(() => {
    const current = messages[index % messages.length];
    let i = 0;
    const typingSpeed = 70;
    const typingDuration = current.length * typingSpeed;
    const totalDisplayTime = 5000;
    const delayAfterTyping = totalDisplayTime - typingDuration;

    const interval = setInterval(() => {
      setDisplayedText(current.slice(0, i + 1));
      i++;
      if (i === current.length) {
        clearInterval(interval);
        setTimeout(() => {
          setIndex((prev) => (prev + 1) % messages.length);
          setKey((prev) => prev + 1);
        }, delayAfterTyping);
      }
    }, typingSpeed);

    return () => clearInterval(interval);
  }, [index]);

  return (
    <section className="min-h-screen flex items-center relative bg-gradient-to-br from-black via-pink-800/30 to-black text-white px-4 py-24 md:py-32 overflow-hidden">
      {/* Removed blur/overlay to improve navbar visibility */}

      <div className="relative z-10 container mx-auto flex flex-col md:flex-row items-center justify-center md:justify-between gap-12 max-w-7xl text-center md:text-left h-full">
        {/* Text Column */}
        <div className="w-full md:w-1/2 text-center md:text-left">
          <AnimatePresence mode="wait">
            <motion.h1
              key={key}
              className="text-4xl md:text-6xl font-extrabold leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-pink-400 to-pink-600"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 1.8 }}
            >
              {displayedText}
              <span className="blinking-cursor ml-1">|</span>
            </motion.h1>
          </AnimatePresence>

          <motion.p
            className="mt-6 text-pink-200 text-lg md:text-xl max-w-xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 2 }}
          >
            Welcome to a new era of motherhood — where love meets technology in the smoothest way possible.
          </motion.p>

          <motion.div
            className="mt-8 flex flex-col sm:flex-row items-center gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
          >
            <button className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-3 rounded-full font-bold shadow-lg transition">
              Start Your Journey
            </button>
            <a
              href="#learn-more"
              className="bg-amber-200 hover:bg-red-200 text-black px-6 py-3 rounded-full font-bold shadow-lg transition"
            >
              Learn More
            </a>
          </motion.div>

          <motion.ul
            className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 text-pink-100 text-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            <li className="flex items-center gap-2">
              <FaHeart className="text-pink-400" /> Built with Love
            </li>
            <li className="flex items-center gap-2">
              <FaStar className="text-pink-400" /> Trusted by Moms
            </li>
            <li className="flex items-center gap-2">
              <FaSmile className="text-pink-400" /> Easy & Beautiful UI
            </li>
          </motion.ul>
        </div>

        {/* Image Column */}
        <AnimatePresence mode="wait">
          <motion.div
            key={key}
            className="w-full md:w-1/2"
            initial={{ opacity: 0, x: 50, y: 10 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, x: 50, y: 10 }}
            transition={{ duration: 1.8 }}
          >
            <img
              src={images[index % images.length]}
              alt="Mother and child"
              className="rounded-xl shadow-xl border border-white/10 w-full max-w-md mx-auto object-cover"
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Scroll Down */}
      <motion.div
        className="absolute bottom-6 left-1/2 transform -translate-x-1/2 text-white/60 text-xl animate-bounce"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2, duration: 3 }}
      >
        <FaArrowDown />
      </motion.div>

      <style jsx>{`
        .blinking-cursor {
          animation: blink 1s step-end infinite;
        }
        @keyframes blink {
          from,
          to {
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </section>
  );
}
