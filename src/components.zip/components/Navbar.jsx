import React, { useState } from "react";
import {FaTimes, FaHome, FaInfoCircle, FaTools, FaUsers,FaComments, FaSignInAlt, FaUserPlus, FaRobot} from "react-icons/fa";
import { HiMenuAlt3 } from "react-icons/hi";
import { motion } from "framer-motion";


const navItems = [
  { label: "Home", icon: <FaHome /> },
  { label: "Features", icon: <FaTools /> },
  { label: "Tools", icon: <FaTools /> },
  { label: "Community", icon: <FaUsers /> },
  { label: "Chatbot", icon: <FaRobot /> },
  { label: "Login", icon: <FaSignInAlt /> },
  { label: "Sign Up", icon: <FaUserPlus /> },
  { label: "About", icon: <FaInfoCircle /> },
  { label: "Contact", icon: <FaComments /> },
];

const iconHover = {
  scale: 1.1,
  rotateY: 360,
  backgroundColor: "#ff69b4",
  color: "#ffffff",
  transition: {
    duration: 1.2,
    ease: "easeInOut",
  },
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Desktop Navbar */}
      <nav className="hidden md:flex fixed top-0 left-0 right-0 z-[100] items-center justify-between px-8 py-4 bg-black text-white shadow-md border-b border-white/10">
        <h1 className="text-3xl font-bold text-pink-800">MamaCare</h1>
        <ul className="flex gap-6 text-sm font-medium">
          {navItems.map(({ label, icon }) => (
            <motion.li
              key={label}
              className="cursor-pointer flex items-center gap-2 p-2 rounded-lg"
              whileHover={iconHover}
              whileTap={{ scale: 0.95 }}
              style={{ backfaceVisibility: "hidden", transformStyle: "preserve-3d" }}
            >
              <span className="text-lg">{icon}</span>
              <span className="hover:text-white-900 transition-all duration-300">{label}</span>
            </motion.li>
          ))}
        </ul>
      </nav>

      {/* Mobile Navbar */}
      <nav className="md:hidden fixed top-0 left-0 right-0 z-[100] bg-black/90 shadow-md p-4 flex items-center justify-between text-white">
        <h1 className="text-2xl font-bold text-pink-800">MamaCare</h1>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="text-2xl focus:outline-none text-white"
        >
          {isOpen ? <FaTimes /> : <HiMenuAlt3 />}
        </button>
      </nav>

      {/* Mobile Drawer Menu */}
      {isOpen && (
        <div className="md:hidden fixed top-16 left-0 right-0 mx-4 bg-black/90 p-4 rounded-xl shadow-2xl text-white z-[99]">
          <ul className="grid grid-cols-3 gap-4 text-sm text-center font-medium">
            {navItems.map(({ label, icon }) => (
              <motion.li
                key={label}
                className="cursor-pointer flex flex-col items-center justify-center p-3 rounded-lg hover:bg-pink-700/30"
                whileHover={iconHover}
                whileTap={{ scale: 0.95 }}
                style={{ backfaceVisibility: "hidden", transformStyle: "preserve-3d" }}
              >
                <div className="text-lg">{icon}</div>
                <span className="text-xs">{label}</span>
              </motion.li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
};

export default Navbar;
