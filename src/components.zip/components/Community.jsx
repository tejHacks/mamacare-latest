export default function Community() {
  return (
    <section className="py-24 px-6 bg-gradient-to-br from-blue-50/10 via-purple-100/5 to-pink-100/10 backdrop-blur-sm text-white">
      <div className="max-w-7xl mx-auto flex flex-col-reverse lg:flex-row items-center gap-16">
        {/* Text Content */}
        <div className="flex-1 text-center lg:text-left">
          <h2 className="text-4xl md:text-5xl font-extrabold mb-6">
            Built For You, By You 💬
          </h2>
          <p className="text-pink-100 text-lg mb-4 max-w-xl">
            Join thousands of mamas and families sharing love, advice, prayers, encouragement, and laughs.
            Our community is more than a feature — it's a lifeline.
          </p>
          <p className="text-pink-200 text-base mb-6 max-w-xl">
            From spiritual support to motherhood hacks, the village is alive — and it's waiting for you.
            No judgment. Just love, wisdom, and real talk.
          </p>
          <a
            href="/auth.html"
            className="inline-block bg-pink-500 hover:bg-pink-600 text-white font-semibold px-6 py-3 rounded-xl shadow-md transition-all duration-300"
          >
            Join The Community
          </a>
        </div>

        {/* Image Placeholder */}
        <div className="flex-1 w-full">
          <div className="w-full aspect-video bg-white/10 rounded-2xl border border-white/20 flex items-center justify-center text-white/30 text-lg italic">
            {/* Replace this with your app screenshot or community preview image later */}
            App Community Preview
          </div>
        </div>
      </div>
    </section>
  );
}
