import { motion } from "framer-motion";

const features = [
  {
    title: "Baby Scheduler & Wellness",
    desc: "Track feeding, sleep, doctor visits & vaccines. All in one cuddly dashboard.",
    emoji: "🍼",
    direction: "left",
  },
  {
    title: "Expense Tracker",
    desc: "Monitor baby-related expenses, diapers to doctor bills, with budgeting ease.",
    emoji: "💰",
    direction: "right",
  },
  {
    title: "Milestone Logger",
    desc: "Capture & archive precious firsts — steps, giggles, and messy face photos.",
    emoji: "📸",
    direction: "left",
  },
  {
    title: "AI Assistant",
    desc: "Ask MamaBot anything — parenting tips, baby food, teething remedies, etc.",
    emoji: "🤖",
    direction: "right",
  },
  {
    title: "Short Daily Reads",
    desc: "Micro-reads to keep mama informed, inspired & uplifted during busy days.",
    emoji: "📚",
    direction: "left",
  },
  {
    title: "Soundboard & Lullabies",
    desc: "Play soothing lullabies, white noise, and heartbeats to calm your little one.",
    emoji: "🎵",
    direction: "right",
  },
];

const floatAnimation = {
  animate: {
    y: [0, -10, 0, 10, 0],
    transition: {
      duration: 4,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
};

const fadeVariants = {
  left: {
    hidden: { opacity: 0, x: -80 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.8 } },
  },
  right: {
    hidden: { opacity: 0, x: 80 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.8 } },
  },
};

export default function Features() {
  return (
    <section className="py-24 px-4 sm:px-8 bg-gradient-to-bl from-pink-50/10 via-pink-100/5 to-purple-100/5">
      <div className="max-w-6xl mx-auto text-center mb-20">
        <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
          Magical Features for Modern Mamas 💖
        </h2>
        <p className="text-pink-200 text-lg max-w-2xl mx-auto">
          Crafted with care, love & tech – for every heartbeat that matters.
        </p>
      </div>

      <div className="space-y-20 max-w-6xl mx-auto">
        {features.map((feature, i) => {
          const isLeft = feature.direction === "left";

          return (
            <motion.div
              key={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeVariants[feature.direction]}
              className={`flex flex-col md:flex-row ${
                isLeft ? "" : "md:flex-row-reverse"
              } items-center justify-between gap-8 md:gap-16`}
            >
              {/* Text Card */}
              <motion.div
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 0 30px rgba(255, 192, 203, 0.4)",
                }}
                className="flex-1 min-w-[280px] max-w-[500px] bg-white/10 backdrop-blur-md p-8 rounded-3xl border border-white/20 text-white shadow-lg transition-all duration-300"
              >
                <h3 className="text-3xl font-extrabold mb-4 flex items-center gap-2">
                  <span className="hidden md:inline">{feature.emoji}</span> {feature.title}
                </h3>
                <p className="text-pink-100 text-md leading-relaxed font-medium">
                  {feature.desc}
                </p>
              </motion.div>

              {/* Floating Emoji */}
              <motion.div
                className="text-[120px] sm:text-[150px] md:text-[180px] lg:text-[200px] leading-none"
                variants={floatAnimation}
                animate="animate"
                whileHover={{ scale: 1.15, rotate: 5 }}
              >
                {feature.emoji}
              </motion.div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
