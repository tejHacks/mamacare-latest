import { motion } from "framer-motion";

export default function CTA() {
  return (
    <section className="bg-pink-600 text-white py-20 px-6 text-center">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        viewport={{ once: true }}
        className="max-w-3xl mx-auto"
      >
        <h2 className="text-4xl md:text-5xl font-extrabold mb-6">
          Ready To Make Mama Life Easier?
        </h2>
        <p className="text-lg md:text-xl mb-8 text-pink-100">
          Join our growing community of smart, strong & spiritual mamas. Track, chat, shop, pray — all in one app.
        </p>
        <a
          href="/signup"
          className="bg-white text-pink-700 font-bold py-3 px-6 rounded-full text-lg shadow-md hover:bg-pink-100 transition"
        >
          Get Started
        </a>
      </motion.div>
    </section>
  );
}
